select r.nome, r.cognome, s.name
from rubrica as r
inner join smartphone as s on
s.id  = r.idRubrica;

update rubrica
set nome = 'Fra', cognome = 'Fari'
where idRubrica=1;

update smartphone
set name = 'LG Q6', ram = '2Gb'
where id=2;

select name, ram, cpu
from smartphone
where name like 'Galaxy%';

INSERT INTO rubrica (idRubrica, smartphone, nome, cognome, numTelefono) VALUES
					(9, 12, 'Marilina', 'Di Chiro', '3334567890');