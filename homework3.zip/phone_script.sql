drop database Phone;

create database if not exists Phone
default character set latin1
default collate latin1_general_ci;

USE Phone;

create table if not exists country (
code varchar(2) not null,
name varchar(32) not null,
primary key(code)
);

create table if not exists brand (
id int(11) not null auto_increment,
name varchar(32) not null,
country varchar(2) not null,
primary key(id),
constraint fk_country foreign key (country) references country (code)
);


create table if not exists opsys (
id int(11) not null auto_increment,
description varchar(64) not null,
company varchar(64) not null,
openSource tinyint (1),
primary key(id)
);


create table if not exists smartphone (
id int(11) not null auto_increment,
name varchar(64),
ram varchar(5),
cpu varchar(64),
displayPpi int(11),
displaySize varchar (12),
displayResolution varchar (64),
size varchar(64),
weight int(4),
notes varchar(1024),
brand int(11),
opSys int(11), 
primary key(id),
constraint fk_brand foreign key (brand) references brand (id),
constraint fk_opsys foreign key (opsys) references opsys (id)

);


create table if not exists rubrica (
idRubrica int(32) not null auto_increment,
smartphone int(11) not null,
nome varchar(64) not null,
cognome varchar(64) not null,
numTelefono varchar(64),
primary key(idRubrica),
constraint fk_nomeSPhone foreign key (smartphone) references smartphone (id)
);

