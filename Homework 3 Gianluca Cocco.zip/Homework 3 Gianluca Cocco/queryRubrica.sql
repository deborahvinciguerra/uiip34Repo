INSERT INTO Rubrica VALUES (5, '393923456', 7, 'lorenzo', 'cocco', '06/03/1959', 'campobasso' );

SELECT r.nome , r.cognome, r.dataNascita, r.luogoNascita, s.name
FROM Rubrica as r
INNER JOIN smartphone as s 
ON r.idRubr = s.id;

UPDATE Rubrica
set nome = 'gigino', cognome = 'gigetto', dataNascita = 'grotta', luogoNascita = 'milano'
WHERE idRubr = 3;


UPDATE smartphone
set name = 'HTC 8.9'
WHERE id = 2;

SELECT name, size, weight
FROM  smartphone
WHERE id = 5;