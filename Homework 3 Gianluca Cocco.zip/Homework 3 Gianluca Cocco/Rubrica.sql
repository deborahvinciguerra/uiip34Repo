drop database Phone;

CREATE 	DATABASE IF NOT EXISTS Phone
default character set latin1
default collate latin1_general_ci;

use Phone;

alter database Phone
default character set utf8
default collate utf8_unicode_ci;


create table if not exists country(
code varchar(2),
name varchar (32) not null,
primary key (code)
);


create table if not exists brand(
id int (11) not null auto_increment,
name varchar (32) not null,
country varchar(2) not null,
primary key (id),
constraint fk_country foreign key (country) references country (code)
);


create table if not exists opsys(
id int (11) not null  auto_increment,
description varchar (64) not null,
company varchar(64) not null,
openSource tinyint(1) not null,
primary key (id)
);

create table if not exists smartphone(
id int (11) not null  auto_increment,
name varchar (64) not null,
ram varchar (5) not null,
cpu varchar (64) not null,
displayPpi int (11) not null,
displaySize varchar (12) not null,
displayResolution varchar (64) not null,
size varchar (64) not null,
weight int (4) not null,
notes varchar (1024) not null,
brand int (11) not null,
opsys int (11) not null,
primary key (id),
constraint fk_brand foreign key (brand) references brand (id),
constraint fk_opsys foreign key (opsys) references opsys (id)
);

create table if not exists Rubrica(
idRubr int (11) not null  auto_increment,
numeroTelefono varchar (64) not null,
smartphone int(11) not null,
nome varchar (64) not null,
cognome varchar(64) not null,
dataNascita varchar(64) not null,
luogoNascita varchar(64) not null,
primary key (idRubr),
constraint fk_smartphone foreign key (smartphone) references smartphone (id)
);

