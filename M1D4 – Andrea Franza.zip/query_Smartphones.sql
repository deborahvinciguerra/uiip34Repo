use phone;

insert into rubrica (nome, cognome, telefono, indirizzo, numeroTel) value
					('Pino', 'Uccio', 12, 'via olmo 23', '3339586023');

select r.nome, r.cognome, s.name from rubrica as r
	inner join smartphone as s on r.telefono=s.id;

update rubrica
	set nome = 'Franco', telefono = 6, numeroTel = '3348602087'
    where (nome, cognome) = ('Pino', 'Uccio');
    
select s.* from rubrica as r
	inner join smartphone as s on r.telefono=s.id;