use phone;

insert into rubrica (nome, cognome, telefono, indirizzo, numeroTel) value
					('Gigi', 'Ino', 5, 'via carpaccio 3', '3379810123'),
					('Natale', 'Ino', 9, 'piazza pizza 95', '3720974927'),
					('Gigi', 'Etto', 12, 'vico fontana 273', '3489502854');
					