CREATE DATABASE if not exists Phone
	DEFAULT CHARACTER SET latin1
    DEFAULT COLLATE latin1_general_ci;
    
USE Phone;

CREATE TABLE if not exists country (
    code VARCHAR (2) NOT NULL PRIMARY KEY,
    name VARCHAR (32) NOT NULL
);

CREATE TABLE if not exists brand (
	id INT(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR (32) NOT NULL,
    country VARCHAR (2) NOT NULL,
    CONSTRAINT pk_id primary key (id),
    CONSTRAINT fk_country FOREIGN KEY (country) REFERENCES country(code)
);

CREATE TABLE if not exists opsys (
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    description VARCHAR (64) NOT NULL,
    company VARCHAR (64) NOT NULL,
    openSource TINYINT (1) NOT NULL
);

CREATE TABLE if not exists smartphone (
	id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR (64) NOT NULL,
    ram VARCHAR (5) NOT NULL,
    cpu VARCHAR (64) NOT NULL,
    displayPpi INT (11) NOT NULL,
    displaySize VARCHAR (12) NOT NULL,
    displayResolution VARCHAR (64) NOT NULL,
    size VARCHAR (64) NOT NULL,
    weight INT (4) NOT NULL,
    notes VARCHAR (1024) NOT NULL,
    brand INT (11) NOT NULL,
    opSys INT (11) NOT NULL,
    CONSTRAINT fk_brand FOREIGN KEY (brand) REFERENCES brand(id),
    CONSTRAINT fk_opSys FOREIGN KEY (opsys) REFERENCES opsys(id)
);

CREATE TABLE if not exists rubrica (
	nome VARCHAR(32) NOT NULL,
    cognome VARCHAR(32) NOT NULL,
    telefono INT(11) NOT NULL,
    indirizzo VARCHAR(64) NOT NULL,
    numeroTel VARCHAR(12) NOT NULL,
    Constraint pk_contatto PRIMARY KEY (nome, cognome),
    constraint fk_telefono FOREIGN KEY (telefono) REFERENCES smartphone(id)
);