drop database biblioteca;

create database if not exists biblioteca

  default character set latin1
   default collate latin1_general_ci;
   

use biblioteca;



create table if not exists libro(
    idLibro int(16) not null auto_increment primary key,
	titolo varchar(64) not null,
	autore varchar(32) not null
);



create table if not exists tessera(
    idTessera int(16) not null auto_increment primary key,
	idLibro int(16),
	nome varchar(32) not null,
	cognome varchar(32) not null,
	indirizzo varchar(32) not null,
	constraint fk_idLibro foreign key(idLibro) references libro(idLibro)
);



