package bibliotecaCocco.model.daoimpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bibliotecaCocco.model.Libro;
import bibliotecaCocco.model.Tessera;

import bibliotecaCocco.model.dao.TesseraDAO;
import bibliotecaCocco.model.daoimpl.ConnectionManager;

public class JdbcTessera implements TesseraDAO {

	public void inserimentoUtente(String nome, String cognome, String indirizzo) {

		Tessera t = new Tessera();
		
		Connection cnn;
		Statement stmt;
		
		try {
			
			 cnn=  ConnectionManager.getConnection();
			 stmt = cnn.createStatement();
			 String query= "INSERT INTO tessera values ("+t.getIdTessera() +",'"+t.getLettore()+"','"+t.getNome()+"','"+t.getCognome() +
					 								"','"+t.getIndirizzo()+");";
			 stmt.executeUpdate(query);
			 cnn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

	
	// associo la id del libro alla id della tessera che ha preso in prestito il libro
	
	public void prestaLibro(int idLibro) {
		
		
		Libro l = new Libro();

		
		Connection cnn;
		Statement stmt;
		ResultSet rs;
		Tessera t=null;
		try {
//			
			 cnn=  ConnectionManager.getConnection();
			 stmt = cnn.createStatement();
			 String query ="SELECT * from tessera WHERE idLibro = ?";
			 rs=stmt.executeQuery(query);
			 
			 t.setIdLibro(l.getIdLibro());
			 
	
			 cnn.close();			 
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		} catch (SQLException e) {

			e.printStackTrace();
		}		
		
		
	}

}
