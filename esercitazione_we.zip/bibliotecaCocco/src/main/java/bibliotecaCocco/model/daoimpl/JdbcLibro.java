package bibliotecaCocco.model.daoimpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bibliotecaCocco.model.Libro;
import bibliotecaCocco.model.dao.LibroDAO;
import bibliotecaCocco.model.daoimpl.ConnectionManager;

public class JdbcLibro implements LibroDAO {

	public void visualizzaElenco() {

		// visualizzazione elenco libri disponibili
		
		Connection cnn;
		Statement stmt;
		
		try {
			
			 cnn=  ConnectionManager.getConnection();
			 stmt = cnn.createStatement();
			
			 
			 System.out.println("Libri disponibili: ");
		      String sql = "SELECT titolo FROM libro";
		      ResultSet rs = stmt.executeQuery(sql);
			 
			 
			 
			 
			 cnn.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

	public Libro cercaTitolo(String titolo) {

		// ricerca libro tramite titolo
		Connection cnn;
		Statement stmt;
		ResultSet rs;
		Libro lib=null;
		try {
			
			 cnn=  ConnectionManager.getConnection();
			 stmt = cnn.createStatement();
			 String query ="SELECT * from libro WHERE titolo= ? ";
			 rs=stmt.executeQuery(query);
			 
			 if (rs.next()) {
				
				int idLibro =rs.getInt("idLibro");
				String titolo1 =rs.getString("titolo");
				String autore =rs.getString("autore");
				lib=new Libro(idLibro,titolo,autore);
			 }
			 cnn.close();			 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return lib ;
	}

	public Libro cercaAutore(String autore) {

		// ricerca libro tramite autore
				Connection cnn;
				Statement stmt;
				ResultSet rs;
				Libro v=null;
				try {
//					
					 cnn=  ConnectionManager.getConnection();
					 stmt = cnn.createStatement();
					 String query ="SELECT * from libro WHERE autore= ?";
					 rs=stmt.executeQuery(query);
					 
					 if (rs.next()) {
						
						int idLibro =rs.getInt("idLibro");
						String titolo1 =rs.getString("titolo");
						String autore1 =rs.getString("autore");
						v=new Libro(idLibro,titolo1,autore1);
					 }
					 cnn.close();			 
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
				return v ;
		
		
		
		
		
		
	}

}
