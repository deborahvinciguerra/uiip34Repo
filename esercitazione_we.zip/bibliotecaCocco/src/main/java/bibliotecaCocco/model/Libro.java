package bibliotecaCocco.model;

public class Libro {

	int idLibro;
	String titolo;
	String autore;
	
	
	public Libro() {}
	
	public Libro(int idLibro, String titolo, String autore) {
		super();
		this.idLibro = idLibro;
		this.titolo = titolo;
		this.autore = autore;
	}


	public int getIdLibro() {
		return idLibro;
	}


	public void setIdLibro(int idLibro) {
		this.idLibro = idLibro;
	}


	public String getTitolo() {
		return titolo;
	}


	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}


	public String getAutore() {
		return autore;
	}


	public void setAutore(String autore) {
		this.autore = autore;
	}

	@Override
	public String toString() {
		return "Libro [idLibro=" + idLibro + ", titolo=" + titolo + ", autore=" + autore + "]";
	}
	
	
}
