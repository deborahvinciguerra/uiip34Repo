package bibliotecaCocco.model;

public class Tessera {

	int idTessera;
	int idLibro;
	String lettore;
	String nome;
	String cognome;
	String indirizzo;
	
	
	public Tessera() {}
	
	public Tessera(int idTessera, int idLibro, String lettore, String nome, String cognome, String indirizzo) {
		super();
		this.idTessera = idTessera;
		this.idLibro = idLibro;
		this.lettore = lettore;
		this.nome = nome;
		this.cognome = cognome;
		this.indirizzo = indirizzo;
	}


	public int getIdLibro() {
		return idLibro;
	}

	public void setIdLibro(int idLibro) {
		this.idLibro = idLibro;
	}

	public int getIdTessera() {
		return idTessera;
	}


	public void setIdTessera(int idTessera) {
		this.idTessera = idTessera;
	}


	public String getLettore() {
		return lettore;
	}


	public void setLettore(String lettore) {
		this.lettore = lettore;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getCognome() {
		return cognome;
	}


	public void setCognome(String cognome) {
		this.cognome = cognome;
	}


	public String getIndirizzo() {
		return indirizzo;
	}


	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	@Override
	public String toString() {
		return "Tessera [idTessera=" + idTessera + ", idLibro=" + idLibro + ", lettore=" + lettore + ", nome=" + nome
				+ ", cognome=" + cognome + ", indirizzo=" + indirizzo + "]";
	}
	
	
}
