package bibliotecaCocco.model.dao;

public interface TesseraDAO {
    
	public void inserimentoUtente(String nome, String cognome, String indirizzo);
	public void prestaLibro (int idLibro );
}
