package bibliotecaCocco.model.dao;

import bibliotecaCocco.model.Libro;

public interface LibroDAO {

	public void visualizzaElenco();
	public Libro cercaTitolo (String titolo);
	public Libro cercaAutore (String autore);
	
}
