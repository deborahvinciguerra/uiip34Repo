create database if not exists Biblioteca_script
default character set latin1
default collate latin1_general_ci;

USE Biblioteca_script;


create table if not exists Libro (
idLibro int(32) not null auto_increment,
titolo varchar(32) not null,
autore varchar(32) not null,
primary key(idLibro)
);

create table if not exists Tessera (
idTessera int(32) not null auto_increment,
idLibro int(32) not null,
nomeUtente varchar(32) not null,
cognomeUtente varchar(32) not null,
indirizzo varchar(32) ,
primary key(idTessera),
constraint fk_idLibro foreign key (idLibro) references Libro (idLibro)
);