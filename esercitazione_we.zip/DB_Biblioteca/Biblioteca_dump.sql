
INSERT INTO Libro (idLibro, titolo, autore)
VALUES  (1, "I dolori del giovane Werther", "W. Goethe"),
		(2, "I fiori del male", "C. Baudelaire"),
        (3, "Vita liquida", "Z. Baumann"),
        (4, "Seta", "A. Baricco"),
        (5, "Novecento", "A. Baricco");
        
INSERT INTO Tessera (idTessera, idLibro, nomeUtente, cognomeUtente, indirizzo)
VALUES  (1, 3, "Francesca", "Farinaccio", "via Monte Grappa, Campobasso"),
		(2, 4, "Gianluca", "Cocco", "via Ungaretti, Campobasso"),
        (3, 1, "Simona", "Di Chiro", "via dei santi, Baranello"),
        (4, 1, "Andrea", "Franzino", "via di qua, Foggia"),
        (5, 2,  "Lucia", "Petrone", "via Monte sangiovino, Montagano(CB)");
        
        