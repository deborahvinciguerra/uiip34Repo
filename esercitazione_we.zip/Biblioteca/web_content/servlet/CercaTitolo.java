package servlet;


import java.io.IOException;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSessionEvent;

import com.HttpSession;
import com.RequestDispatcher;
import com.model.Contatto;

import dao.impl.JDBCLibroDAO;

/**
 * Servlet implementation class CercaTitolo
 */
public class CercaTitolo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	JDBCLibroDAO l;
	
    public CercaTitolo() {
        super();
        
        l.cercaTitolo("titolo");
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession sess = request.getSession(true);
		String titolo = request.getParameter("titolo");
		
		sess.setAttribute("jdbclibro", titolo);
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
        dispatcher.forward(request, response);
		
		
		
	}

}
