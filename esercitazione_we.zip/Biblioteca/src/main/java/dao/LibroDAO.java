package dao;

import it.model.Libro;

public interface LibroDAO {
	
	public void inserisciLibro(Libro libro);
	public void visualizzaElenco();
	public Libro cercaTitolo(String titolo);
	public Libro cercaAutore(String autore);

}
