package dao;

import it.model.Libro;

public interface TesseraDAO {
	
	public void prestaLibro(String codLibro);
	
	//metodo per far inserire i dati anagrafici dell'utente 
	public void inserisciDati(String nUt, String cUt, String indir);

}
