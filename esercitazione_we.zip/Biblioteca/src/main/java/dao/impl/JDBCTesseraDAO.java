package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import dao.TesseraDAO;
import it.model.Libro;
import it.model.Tessera;

public class JDBCTesseraDAO implements TesseraDAO {

	Tessera t = new Tessera ();
	Libro l= new Libro();
	
	private DataSource dataSource;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	
	//metodo che associa l'id del libro al codice libro della tessera, che nel db è una fk
	public void prestaLibro(String codLibro) {

		String sql = "SELECT * FROM TESSERA WHERE codLibro = ?";
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, codLibro);
			Tessera tessera  = null;
			
			ResultSet rs = ps.executeQuery();
			
			t.setCodLibro(l.getIdLibro());
			
			rs.close();
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
		
		
	}

	//metodo per inserire i dati di un nuovo utente compreso in Tessera
	public void inserisciDati(String nUt, String cUt, String indir) {

		
		Connection conn = null;
		Statement stmt;
		ResultSet result;
		
		try {
			conn = dataSource.getConnection();
			
			
			String sql = "INSERT INTO tessera VALUES ( "+ t.getIdTessera() + " ," + t.getCodLibro() + " ," + t.getNomeUtente() +" ," + t.getCognomeUtente() +" ," + t.getIndirizzo() ;
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery(sql);
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
		
	}

}
