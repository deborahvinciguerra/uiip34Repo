package dao.impl;

import java.sql.*;
import java.sql.SQLException;
import javax.sql.DataSource;

import dao.LibroDAO;
import it.model.Libro;

public class JDBCLibroDAO implements LibroDAO {
	
	private DataSource dataSource;
	Libro l = new Libro();

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	
	
	
	public void visualizzaElenco() {

		Connection conn = null;
		Statement stmt;
		
		try {
			conn = dataSource.getConnection();
			String sql = "SELECT titolo FROM Libro " ;
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs = ps.executeQuery(sql);
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
	}
		
		
		
	
	//metodo per eseguire una query sull'autore
	public Libro cercaTitolo(String titolo) {
		
		String sql = "SELECT * FROM LIBRO WHERE titolo = ?";
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, titolo);
			Libro libro = null;
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				Libro l = new Libro(
					rs.getString("id_libro"),
					rs.getString("titolo"), 
					rs.getString("autore")
				);
			}
			rs.close();
			ps.close();
			return l;
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}

	
	
	
	//metodo per eseguire una query sull'autore
	public Libro cercaAutore(String autore) {

		String sql = "SELECT * FROM LIBRO WHERE autore = ?";
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, autore);
			Libro libro = null;
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				Libro l = new Libro(
					rs.getString("id_libro"),
					rs.getString("titolo"), 
					rs.getString("autore")
				);
			}
			rs.close();
			ps.close();
			return l;
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
		} finally {
			if (conn != null) {
				try {
				conn.close();
				} catch (SQLException e) {}
			}
		}
	}

	
	
	
	//metodo per inserire un libro
	public void inserisciLibro(Libro libro) {

		String sql = "INSERT INTO LIBRO " +
				"(ID_LIBRO, TITOLO, AUTORE) VALUES (?, ?, ?)";
		Connection conn = null;
		
		try {
			conn = dataSource.getConnection();
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, libro.getIdLibro());
			ps.setString(2, libro.getTitolo());
			ps.setString(3, libro.getAutore());
			ps.executeUpdate();
			ps.close();
			
		} catch (SQLException e) {
			throw new RuntimeException(e);
			
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {}
			}
		}
	}
		
		
	
}


