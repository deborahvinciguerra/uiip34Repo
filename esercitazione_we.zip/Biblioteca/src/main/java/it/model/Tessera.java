package it.model;

public class Tessera {
	
	private String idTessera;
	private String codLibro;
	private String nomeUtente;
	private String cognomeUtente;
	private String indirizzo;
	
	
	public Tessera () {}
	
	public Tessera(String idTessera, String codLibro, String nomeUtente, String cognomeUtente, String indirizzo) {
		super();
		this.idTessera = idTessera;
		this.codLibro = codLibro;
		this.nomeUtente = nomeUtente;
		this.cognomeUtente = cognomeUtente;
		this.indirizzo = indirizzo;
	}


	public String getIdTessera() {
		return idTessera;
	}


	public void setIdTessera(String idTessera) {
		this.idTessera = idTessera;
	}


	public String getCodLibro() {
		return codLibro;
	}


	public void setCodLibro(String codLibro) {
		this.codLibro = codLibro;
	}


	public String getNomeUtente() {
		return nomeUtente;
	}


	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}


	public String getCognomeUtente() {
		return cognomeUtente;
	}


	public void setCognomeUtente(String cognomeUtente) {
		this.cognomeUtente = cognomeUtente;
	}


	public String getIndirizzo() {
		return indirizzo;
	}


	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	@Override
	public String toString() {
		return "Tessera [idTessera=" + idTessera + ", codLibro=" + codLibro + ", nomeUtente=" + nomeUtente
				+ ", cognomeUtente=" + cognomeUtente + ", indirizzo=" + indirizzo + "]";
	}
	
	
}
