package it.model;

public class Libro {

	private String idLibro;
	private String titolo;
	private String autore;
	
	
	public Libro() {}
	
	public Libro(String idLibro, String titolo, String autore) {
		super();
		this.idLibro = idLibro;
		this.titolo = titolo;
		this.autore = autore;
	}


	public String getIdLibro() {
		return idLibro;
	}


	public void setIdLibro(String idLibro) {
		this.idLibro = idLibro;
	}


	public String getTitolo() {
		return titolo;
	}


	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}


	public String getAutore() {
		return autore;
	}


	public void setAutore(String autore) {
		this.autore = autore;
	}

	@Override
	public String toString() {
		return "Libro [idLibro=" + idLibro + ", titolo=" + titolo + ", autore=" + autore + "]";
	}
	
			
}
