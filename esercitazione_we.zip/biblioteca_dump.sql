SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT;
SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS;
SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION;
SET NAMES utf8;
SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';
SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0; 
        
        
        
INSERT INTO libro (idLibro,titolo,autore)
 VALUES (5, "interpretazione dei sogni", "sigmund freud"), 
		(8, "l insostenibile leggerezza", "milan kundera"), 
        (13, "i ragazzi dello zoo di berlino", "christian f."); 
        
        
INSERT INTO tessera (idTessera,idLibro,nome,cognome,indirizzo)
 VALUES (4,55, " gianluca", "cocco", "via ungaretti"), 
		(7,56, " gigino", "gigetto", "piazza navona"), 
        (12,97, " ludovico", "riginaldo", "piazza vittoria"); 
        
        
        
        
SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT;
SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS;
SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION;
SET SQL_NOTES=@OLD_SQL_NOTES; 