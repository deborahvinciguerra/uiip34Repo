create database if not exists rubrica;
use rubrica;

Create table if not exists utente(
idUtente varchar(10) not null primary key,
nome varchar(20) not null,
cognome varchar(20) not null
);


Create table if not exists sim(
Imei varchar(25) not null primary key ,
pin varchar(10) not null,
puk varchar(10) not null,
numerotelefono varchar(10) not null
);


Create table if not exists country(
 code varchar(2) not null primary key,
 name varchar(32)not null
 );
 
 Create Table brand(
id int(11) not null primary key,
name varchar(32)not null,
country varchar(2)not null,
constraint fk_country FOREIGN KEY (country) REFERENCES country(code));

CREATE TABLE opsys (
    id INT(11) NOT NULL PRIMARY KEY,
    description VARCHAR(64)not null,
    company VARCHAR(64)not null,
    openSource TINYINT(1)not null
);


create table Smartphone(
id int(11) not null primary key,
name varchar(64) not null,
ram varchar (64)not null,
cpu varchar(64) not null,
displayPpi int(11)not null,
displaySize varchar(12)not null,
displayResolution Varchar(64)not null,
size varchar(64)not null,
weight int(4)not null,
notes varchar(1024)not null,
brand int(11)not null,
opSys int(11)not null,
utente varchar(10) not null,
constraint fk_brand FOREIGN KEY (brand) REFERENCES brand (id),
constraint fk_opSys FOREIGN KEY (opSys) REFERENCES opsys (id),
constraint fk_utente FOREIGN KEY (utente) REFERENCES utente(idUtente));

