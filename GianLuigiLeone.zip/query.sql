/*stampa tutti gli utenti e i relativi smartphone*/
Select utente.* ,smartphone.name
from utente inner join smartphone on utente.it=smartphone.utente;

/*modifica del pin sulla sim*/
UPDATE sim
SET pin='87852';
/*stampa di tutti gli smartphone*/
Select smartphone.* 
from smartphone;